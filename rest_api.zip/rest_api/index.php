<?php
    $uri = $_SERVER['REQUEST_URI'];
    $method = $_SERVER['REQUEST_METHOD'];
    
    $uri = explode("?",$uri)[0];
    $uri = explode("/",$uri);
    $inicio = 4;
    
    if ($method=="GET" and $uri[$inicio]=="login" and count($uri)==5)
    {
        include("forms/login.html");
    }
    else if ($method=="POST" and $uri[$inicio]=="login" and count($uri)==5)
    {
        echo "{$_POST['usuario']} - {$_POST['senha']}";
    }
    else
    {
        $resposta = ['uri'=>$uri,'method'=>$method];
        echo json_encode($resposta);
    }
?>